import { randomUUID } from "node:crypto";
import type {
  AssistantMessageEvent,
  Context,
  Model,
  SimpleStreamOptions,
  StreamFn,
} from "@openclaw/llm-core";
import OpenAI from "openai";
import type { ChatCompletion, ChatCompletionChunk } from "openai/resources/chat/completions.js";
import { getEnvApiKey } from "../env-api-keys.js";
import { getAiTransportHost } from "../host.js";
import {
  codeModeToolSurfaceObserver,
  reasoningTagTextPolicy,
  type OpenAICompletionsOptions,
} from "../provider-options.js";
import { resolveProviderContext } from "../provider-types.js";
import { resolveCacheRetention } from "../providers/cache-retention.js";
import { buildCopilotDynamicHeaders } from "../providers/github-copilot-headers.js";
import { finalizeOpenAICompletionsToolCalls } from "../providers/openai-completions-tool-calls.js";
import { createOpenAIProviderClient } from "../providers/openai-provider-client.js";
import { mapOpenAIStopReason } from "../providers/openai-stop-reason.js";
import { toOpenAIResponsesToolChoice } from "../providers/openai-tool-projection.js";
import { notifyLlmRequestActivity } from "../utils/llm-request-activity.js";
import {
  createFirstStreamEventAbortController,
  getFirstStreamEventTimeoutHandler,
  getFirstStreamEventTimeoutMs,
  withFirstStreamEventTimeout,
} from "../utils/stream-first-event-timeout.js";
import { boundResponseBody } from "../utils/streaming-byte-guard.js";
import { createAssistantOutput } from "./assistant-output.js";
import { buildGuardedModelFetch } from "./host-policy.js";
import { prepareModelRequestBody } from "./model-request-body.js";
import { hasOpenAICompatibleConversationTurn } from "./openai-compatible-conversation-turn.js";
import {
  isNativeOpenAIEndpoint,
  resolveOpenAICompletionsCompat,
} from "./openai-completions-compat.js";
import { isAzureOpenAICompatibleHost } from "./openai-completions-host.js";
import {
  buildOpenAICompletionsRequest,
  resolveCompletionsContextOutputBudget,
} from "./openai-completions-params.js";
import {
  processCompletionsStream,
  observeOpenAICompletionsProgress,
  shouldEmitOpenAICompletionsReasoning,
} from "./openai-completions-stream.js";
import { createOpenAIResponsesTransportStreamFn } from "./openai-responses-client.js";
import type { OpenAIResponsesOptions } from "./openai-responses-contracts.js";
import {
  assertCodeModeResponsesToolSurface,
  buildOpenAIClientHeaders,
  buildOpenAISdkClientOptions,
  buildOpenAISdkRequestOptions,
  enforceCodeModeResponsesToolSurface,
  getCompat,
  resolveCodeModeResponsesVisibleToolNames,
} from "./openai-transport-params.js";
import {
  createOpenAIProviderAcceptanceHook,
  resolveOpenAIClientBaseUrl,
  resolvePromptCacheKey,
  withOpenAIErrorResponseHook,
  type MutableAssistantOutput,
} from "./openai-transport-shared.js";
import {
  filterProviderTurnHeadersForExplicitOpencodeSession,
  resolveProviderSimpleCompletionHeaders,
  resolveProviderTransportTurnState,
} from "./provider-transport-turn-state.js";
import { resolveOpencodeSessionHeaders } from "./session-affinity.js";
import {
  awaitProviderLifecycleCallback,
  createWritableTransportEventStream,
  failTransportStream,
  finalizeTransportStream,
  transportAbortError,
  withProviderResponseHook,
} from "./transport-stream-shared.js";
import { supportsModelTools } from "./transport-utils.js";

export { buildOpenAICompletionsParams } from "./openai-completions-params.js";

function assertOpenAICompletionsPayloadHasConversationTurn(
  params: Record<string, unknown>,
  model: Model,
): void {
  const messages = params.messages;
  if (!Array.isArray(messages) || hasOpenAICompatibleConversationTurn(messages)) {
    return;
  }
  throw new Error(
    `OpenAI-compatible chat payload for ${model.provider}/${model.id} contains no non-empty user or assistant messages after compaction and transport transforms; refusing to send a system/tool-only request. Start a new user turn or repair the compacted session history.`,
  );
}

// Bound provider chunks, not repeated cumulative assistant snapshots. A normal
// multi-token reasoning response otherwise exhausts the event buffer quadratically.
const MAX_CONTEXT_BUDGET_BUFFER_CHUNKS = 8_192;
const MAX_CONTEXT_BUDGET_BUFFER_BYTES = 4 * 1_024 * 1_024;
type Completion = ChatCompletionChunk | ChatCompletion;

const SSE_DONE_LINE_RE = /^data:[ \t]*\[DONE\][ \t]*$/i;
const SSE_DONE_MAX_LINE_CHARS = 1_024;

function createSseDoneDetector() {
  const decoder = new TextDecoder();
  let line = "";
  let lineOverflowed = false;
  let sawDone = false;

  const finishLine = () => {
    if (!lineOverflowed && SSE_DONE_LINE_RE.test(line)) {
      sawDone = true;
    }
    line = "";
    lineOverflowed = false;
  };
  const observeText = (text: string) => {
    for (const [index, segment] of text.split(/[\r\n]/).entries()) {
      if (index > 0) {
        finishLine();
      }
      if (!lineOverflowed && line.length + segment.length <= SSE_DONE_MAX_LINE_CHARS) {
        line += segment;
      } else {
        lineOverflowed = true;
      }
    }
  };

  return {
    observe(chunk: Uint8Array) {
      if (!sawDone) {
        observeText(decoder.decode(chunk, { stream: true }));
      }
    },
    finish() {
      if (sawDone) {
        return;
      }
      observeText(decoder.decode());
      if (line || lineOverflowed) {
        finishLine();
      }
    },
    sawDone: () => sawDone,
  };
}

function createDirectCompletionsEventStream(
  output: MutableAssistantOutput,
  stream: { push(event: AssistantMessageEvent): void },
) {
  type StreamingBlock = MutableAssistantOutput["content"][number];
  const finishedBlocks = new Set<StreamingBlock>();
  const contentIndices = new WeakMap<StreamingBlock, number>();
  let openTextBlock: StreamingBlock | undefined;
  let openThinkingBlock: StreamingBlock | undefined;
  const finishBlock = (block: StreamingBlock) => {
    const contentIndex = contentIndices.get(block);
    if (contentIndex === undefined || finishedBlocks.has(block)) {
      return;
    }
    finishedBlocks.add(block);
    if (block.type === "text") {
      openTextBlock = undefined;
      stream.push({ type: "text_end", contentIndex, content: block.text, partial: output });
    } else if (block.type === "thinking") {
      openThinkingBlock = undefined;
      stream.push({
        type: "thinking_end",
        contentIndex,
        content: block.thinking,
        partial: output,
      });
    } else if (block.type === "toolCall") {
      stream.push({ type: "toolcall_end", contentIndex, toolCall: block, partial: output });
    }
  };
  const eventStream = {
    push(event: Parameters<typeof stream.push>[0]) {
      if (
        event.type === "text_start" ||
        event.type === "thinking_start" ||
        event.type === "toolcall_start"
      ) {
        const block = output.content[event.contentIndex];
        if (block) {
          contentIndices.set(block, event.contentIndex);
          if (block.type === "text") {
            openTextBlock = block;
          } else if (block.type === "thinking") {
            openThinkingBlock = block;
          }
        }
      }
      stream.push(event);
    },
  };
  return {
    stream: eventStream,
    beforeContentBlock: (nextType: "text" | "thinking" | "toolCall") => {
      if (openThinkingBlock) {
        finishBlock(openThinkingBlock);
      }
      if (openTextBlock && nextType !== "toolCall") {
        finishBlock(openTextBlock);
      }
    },
    finish(includeToolCalls: boolean) {
      for (const block of output.content) {
        if (block.type !== "toolCall" || includeToolCalls) {
          finishBlock(block);
        }
      }
    },
  };
}

export function createOpenAICompletionsTransportStreamFn(): StreamFn {
  const streamResponses = createOpenAIResponsesTransportStreamFn();
  return (model, context, options) => {
    const completionsOptions = options as OpenAICompletionsOptions | undefined;
    // Official Chat Completions rejects function tools alongside reasoning for
    // current GPT models; Responses serves the same API-key route and keeps reasoning.
    if (
      model.reasoning &&
      context.tools?.length &&
      supportsModelTools(model) &&
      isNativeOpenAIEndpoint(model)
    ) {
      const toolChoice = completionsOptions?.toolChoice;
      const responsesOptions: SimpleStreamOptions &
        Pick<OpenAIResponsesOptions, "reasoningEffort" | "toolChoice"> = {
        ...options,
        // Managed Completions defaults an unset selector to high; Responses would
        // otherwise apply its own model default, which is none for some models.
        ...(completionsOptions?.reasoning === undefined &&
        completionsOptions?.reasoningEffort === undefined
          ? { reasoningEffort: "high" }
          : {}),
        ...(toolChoice && typeof toolChoice === "object"
          ? { toolChoice: toOpenAIResponsesToolChoice(toolChoice) }
          : {}),
      };
      return streamResponses(
        getAiTransportHost().inheritManagedTransport(model, { ...model, api: "openai-responses" }),
        context,
        responsesOptions,
      );
    }
    return streamOpenAICompletionsRequest(
      model as Model<"openai-completions">,
      context,
      completionsOptions,
      "managed",
    );
  };
}

export function streamOpenAICompletionsRequest(
  model: Model<"openai-completions">,
  context: Context,
  options: OpenAICompletionsOptions | undefined,
  mode: "direct" | "managed",
) {
  const { eventStream, stream } = createWritableTransportEventStream();
  void (async () => {
    const output: MutableAssistantOutput = createAssistantOutput(model);
    let discardCandidate = false;
    let firstEventAbort: ReturnType<typeof createFirstStreamEventAbortController> | undefined;
    try {
      const requestContext = await resolveProviderContext(context, options);
      const apiKey = options?.apiKey || getEnvApiKey(model.provider) || "";
      const cacheRetention = resolveCacheRetention(options?.cacheRetention);
      const policy =
        mode === "direct"
          ? { mode, compat: resolveOpenAICompletionsCompat(model), cacheRetention }
          : { mode };
      const { client, sawStreamDONE } =
        policy.mode === "direct"
          ? {
              client: (() => {
                const sessionId = cacheRetention === "none" ? undefined : options?.sessionId;
                const compat = policy.compat;
                if (!apiKey) {
                  throw new Error(`No API key for provider: ${model.provider}`);
                }
                const headers = { ...model.headers };
                if (model.provider === "github-copilot") {
                  Object.assign(headers, buildCopilotDynamicHeaders(context.messages));
                }
                if (sessionId && compat.sessionAffinity !== "none") {
                  if (compat.sessionAffinity === "openrouter") {
                    headers["x-session-id"] = sessionId;
                  } else {
                    headers.session_id = sessionId;
                    headers["x-client-request-id"] = sessionId;
                    headers["x-session-affinity"] = sessionId;
                  }
                }
                return createOpenAIProviderClient(
                  model,
                  apiKey,
                  headers,
                  resolveProviderSimpleCompletionHeaders(model, options),
                  options?.onResponse,
                );
              })(),
              sawStreamDONE: undefined,
            }
          : (() => {
              const turnState = resolveProviderTransportTurnState(model, {
                sessionId: options?.sessionId,
                turnId: randomUUID(),
                attempt: 1,
                transport: "stream",
              });
              const optionHeaders = resolveOpencodeSessionHeaders(model, options);
              const turnHeaders = filterProviderTurnHeadersForExplicitOpencodeSession(
                model,
                options,
                turnState?.headers,
              );
              // The SDK consumes DONE without yielding it; native tool calls need to distinguish it from EOF.
              const doneDetector = createSseDoneDetector();
              // The SDK replaces the fetch signal; keep liveness keyed to the exact
              // caller signal watched by the idle timer.
              const baseFetch = withOpenAIErrorResponseHook(
                buildGuardedModelFetch(model, undefined, {
                  onSseComment: () => notifyLlmRequestActivity(options?.signal, false),
                }),
                options?.onResponse,
                model,
              );
              const doneDetectingFetch: typeof globalThis.fetch = async (url, init) => {
                const response = await baseFetch(url, init);
                if (!response.body || !response.ok) {
                  return response;
                }
                if (typeof TransformStream === "undefined" || !response.body.pipeThrough) {
                  return response;
                }
                const transformed = response.body.pipeThrough(
                  new TransformStream<Uint8Array, Uint8Array>({
                    transform(chunk, controller) {
                      doneDetector.observe(chunk);
                      controller.enqueue(chunk);
                    },
                    flush() {
                      doneDetector.finish();
                    },
                  }),
                );
                return new Response(transformed, response);
              };
              const headers = buildOpenAIClientHeaders(
                model,
                context,
                { ...turnHeaders, ...optionHeaders },
                undefined,
                resolvePromptCacheKey(options, cacheRetention),
                cacheRetention,
              );
              const defaultQuery: Record<string, string> = {};
              let baseURL = model.baseUrl;
              let isAzureHost = false;

              // Keep invalid configured URLs unchanged so the OpenAI SDK owns their errors.
              const parsed = URL.parse(model.baseUrl);
              if (parsed) {
                isAzureHost = isAzureOpenAICompatibleHost(parsed.hostname.toLowerCase());
                parsed.searchParams.forEach((value, key) => {
                  if (value) {
                    defaultQuery[key] = value;
                  }
                });
                parsed.search = "";
                baseURL = parsed.toString().replace(/\/$/, "");
              }

              if (isAzureHost) {
                const apiVersionHeader = Object.keys(headers).find(
                  (key) => key.toLowerCase() === "api-version",
                );
                if (apiVersionHeader) {
                  const apiVersion = headers[apiVersionHeader]?.trim();
                  delete headers[apiVersionHeader];
                  if (apiVersion && !defaultQuery["api-version"]) {
                    defaultQuery["api-version"] = apiVersion;
                  }
                }
              }

              const resolvedBaseURL = resolveOpenAIClientBaseUrl(model, baseURL);
              const resolvedDefaultQuery =
                Object.keys(defaultQuery).length > 0 ? defaultQuery : undefined;
              return {
                client: new OpenAI({
                  apiKey,
                  baseURL: resolvedBaseURL,
                  dangerouslyAllowBrowser: true,
                  defaultHeaders: headers,
                  defaultQuery: resolvedDefaultQuery,
                  fetch: doneDetectingFetch,
                  ...buildOpenAISdkClientOptions(model),
                }),
                sawStreamDONE: doneDetector.sawDone,
              };
            })();
      const builtParams = buildOpenAICompletionsRequest(model, requestContext, options, policy);
      let params = builtParams;
      const encodeBody = prepareModelRequestBody(options);
      const nextParams = await awaitProviderLifecycleCallback(
        options?.onPayload ? () => options.onPayload?.(params, model) : undefined,
        options?.signal,
      );
      if (nextParams !== undefined) {
        params = nextParams as typeof params;
      }
      if (mode === "managed") {
        if (
          (options as { openclawCodeModeToolSurface?: unknown } | undefined)
            ?.openclawCodeModeToolSurface === true
        ) {
          const visibleToolNames = resolveCodeModeResponsesVisibleToolNames(context);
          enforceCodeModeResponsesToolSurface(
            params,
            visibleToolNames,
            undefined,
            codeModeToolSurfaceObserver.get(options),
          );
          assertCodeModeResponsesToolSurface(params, visibleToolNames);
        }
        if (getCompat(model).requiresNonEmptyUserOrAssistantMessage) {
          assertOpenAICompletionsPayloadHasConversationTurn(params, model);
        }
      }
      const contextOutputBudget = resolveCompletionsContextOutputBudget(builtParams, params);
      const emitReasoning = shouldEmitOpenAICompletionsReasoning(model, options, mode);
      firstEventAbort = createFirstStreamEventAbortController(options?.signal);
      const requestOptions =
        mode === "direct"
          ? {
              ...(await encodeBody(params)),
              signal: firstEventAbort.signal,
              ...(options?.timeoutMs !== undefined ? { timeout: options.timeoutMs } : {}),
              maxRetries: 0,
            }
          : {
              ...buildOpenAISdkRequestOptions(model, firstEventAbort.signal, {
                timeoutMs: options?.timeoutMs,
              }),
              ...(await encodeBody(params)),
            };
      const request = client.chat.completions.create(
        params as OpenAI.Chat.Completions.ChatCompletionCreateParams,
        requestOptions,
      );
      const response = await request.asResponse();
      const responseStream = {
        async *[Symbol.asyncIterator]() {
          // Parse only after provider acceptance; JSON bodies are consumed here too.
          if (!params.stream) {
            yield (await boundResponseBody(response, {
              maxBytes: 16 * 1024 * 1024,
              onOverflow: ({ maxBytes }) =>
                new Error(`Chat Completions JSON response exceeds ${maxBytes} bytes`),
            }).json()) as OpenAI.Chat.Completions.ChatCompletion; // SAFETY: Provider JSON follows the Chat Completions wire contract.
            return;
          }
          const data = await request;
          if (Symbol.asyncIterator in data) {
            yield* data;
          } else {
            yield data;
          }
        },
      };
      const hookedResponseStream = withProviderResponseHook({
        stream: responseStream,
        signal: firstEventAbort.signal,
        abort: firstEventAbort.abort,
        hook: createOpenAIProviderAcceptanceHook(options, response, model),
        onReady: () => {
          if (contextOutputBudget === undefined) {
            stream.push({ type: "start", partial: output });
          }
        },
      });
      const providerStream = observeOpenAICompletionsProgress(
        withFirstStreamEventTimeout(hookedResponseStream, {
          provider: model.provider,
          api: model.api,
          model: model.id,
          timeoutMs: getFirstStreamEventTimeoutMs(options) ?? 0,
          stage: "completions",
          abort: firstEventAbort.abort,
          onTimeout: getFirstStreamEventTimeoutHandler(options),
          hint: "The provider may be stalled while parsing the tool payload; retry with a smaller tool surface or enable OPENCLAW_DEBUG_MODEL_PAYLOAD=tools to inspect exposed tools.",
        }),
        options?.signal,
      );
      const buffered =
        contextOutputBudget === undefined
          ? undefined
          : await (async () => {
              const iterator = providerStream[Symbol.asyncIterator]();
              const chunks: Completion[] = [];
              let bufferedBytes = 0;
              let overflow: IteratorYieldResult<Completion> | undefined;
              let finished = false;
              let failed = false;
              let sourceError: unknown;
              let finishReason: string | undefined;
              try {
                for (;;) {
                  const next = await iterator.next();
                  if (next.done) {
                    finished = true;
                    break;
                  }
                  const chunk = next.value;
                  const chunkBytes = Buffer.byteLength(JSON.stringify(chunk) ?? "", "utf8");
                  if (
                    chunks.length >= MAX_CONTEXT_BUDGET_BUFFER_CHUNKS ||
                    bufferedBytes + chunkBytes > MAX_CONTEXT_BUDGET_BUFFER_BYTES
                  ) {
                    overflow = next;
                    break;
                  }
                  chunks.push(chunk);
                  bufferedBytes += chunkBytes;
                  const chunkFinishReason = chunk?.choices?.[0]?.finish_reason;
                  if (chunkFinishReason) {
                    finishReason = mapOpenAIStopReason(chunkFinishReason).stopReason;
                  }
                  options?.signal?.throwIfAborted();
                }
              } catch (error) {
                failed = true;
                sourceError = error;
                // Replay the received prefix into the reducer before surfacing this error,
                // retaining real provider usage without publishing incomplete candidate tools.
                void iterator.return?.(undefined).catch(() => undefined);
              }
              const bounded = overflow === undefined;
              return {
                bounded,
                failed,
                finishReason,
                stream: {
                  async *[Symbol.asyncIterator]() {
                    try {
                      yield* chunks;
                      if (failed) {
                        throw sourceError;
                      }
                      if (overflow !== undefined) {
                        yield overflow.value;
                        for (;;) {
                          const next = await iterator.next();
                          if (next.done) {
                            finished = true;
                            return;
                          }
                          yield next.value;
                        }
                      }
                    } finally {
                      chunks.length = 0;
                      if (!finished && !failed) {
                        void iterator.return?.(undefined).catch(() => undefined);
                      }
                    }
                  },
                },
              };
            })();
      discardCandidate = Boolean(
        buffered?.bounded && (buffered.failed || buffered.finishReason === "length"),
      );
      if (buffered && !discardCandidate) {
        stream.push({ type: "start", partial: output });
      }
      const directEvents =
        mode === "direct" ? createDirectCompletionsEventStream(output, stream) : undefined;
      try {
        await processCompletionsStream(
          buffered?.stream ?? providerStream,
          output,
          model,
          discardCandidate ? { push() {} } : (directEvents?.stream ?? stream),
          {
            ...(directEvents
              ? {
                  mode: "direct" as const,
                  beforeContentBlock: directEvents.beforeContentBlock,
                }
              : { mode: "managed" as const }),
            signal: discardCandidate ? undefined : options?.signal,
            emitReasoning,
            strictReasoningTags: reasoningTagTextPolicy.isStrict(options),
            sawStreamDONE,
          },
        );
        if (discardCandidate) {
          throw new Error(
            `Context length exceeded: automatic output budget of ${contextOutputBudget} tokens exhausted before completion.`,
          );
        }
        if (directEvents) {
          if (options?.signal?.aborted) {
            throw transportAbortError(options.signal);
          }
          if (output.stopReason === "aborted" || output.stopReason === "error") {
            throw new Error(
              output.errorMessage ||
                (output.stopReason === "aborted"
                  ? "Request was aborted"
                  : "Provider returned an invalid tool call"),
            );
          }
        }
      } catch (error) {
        directEvents?.finish(false);
        throw error;
      }
      directEvents?.finish(output.stopReason === "toolUse");
      finalizeTransportStream({ stream, output, signal: options?.signal });
    } catch (error) {
      if (discardCandidate) {
        output.content = [];
      }
      failTransportStream({
        stream,
        output,
        signal: options?.signal,
        error,
        cleanup: () => {
          finalizeOpenAICompletionsToolCalls(output, { allowSilentToolCallPromotion: false });
        },
      });
    } finally {
      firstEventAbort?.dispose();
    }
  })();
  return eventStream;
}
