// Host policy ports for the reusable transport package. Fetch guarding,
// secret redaction, strict-tool policy, and diagnostics logging are owned by
// the embedding application (OpenClaw core installs its implementations via
// configureAiTransportHost); the library defaults below are inert so external
// consumers get safe, dependency-free behavior without wiring anything.
import type { Api, Context, Model, ModelRequestHeaders, StreamFn } from "@openclaw/llm-core";
import type { ApiRegistry } from "./api-registry.js";
import { transformMessages } from "./transcript-transform.js";

/** Provider capability facts needed by the package-owned transports. */
export interface AiProviderRequestCapabilities {
  endpointClass: string;
  knownProviderFamily: string;
  supportsNativeStreamingUsageCompat: boolean;
  supportsOpenAICompletionsStreamingUsageCompat: boolean;
  usesExplicitProxyLikeEndpoint: boolean;
  allowsAnthropicServiceTier: boolean;
}

/** Transport-safe provider policy input kept independent of OpenClaw config types. */
export interface AiProviderRequestPolicyInput {
  provider?: string;
  api?: string;
  baseUrl?: string;
  capability?: "llm" | "audio" | "image" | "video" | "other";
  transport?: "stream" | "websocket" | "http" | "media-understanding";
  modelId?: string | null;
  compat?: unknown;
  model?: object;
}

/** Context shared by plugin-owned provider stream hooks. */
export interface AiProviderStreamHookContext {
  config?: unknown;
  agentId?: string;
  agentDir?: string;
  workspaceDir?: string;
  /** Selected credential facts supplied by the host; never credential material. */
  auth?: { mode: string; authFlow?: string };
  provider: string;
  modelId: string;
  model: Model;
  /** Wire-format API before simple completion projects an internal transport alias. */
  sourceApi?: Api;
}

/** Narrow plugin-runtime port used by package-owned transports. */
export interface AiTransportPluginHost {
  resolveProviderStream(
    this: void,
    params: {
      provider: string;
      config?: unknown;
      workspaceDir?: string;
      env?: NodeJS.ProcessEnv;
      allowRuntimePluginLoad?: boolean;
      context: AiProviderStreamHookContext;
    },
  ): StreamFn | undefined;
  resolveTransportTurnState(
    this: void,
    params: {
      provider: string;
      modelId?: string | null;
      config?: unknown;
      workspaceDir?: string;
      env?: NodeJS.ProcessEnv;
      allowRuntimePluginLoad?: boolean;
      context: {
        provider: string;
        modelId: string;
        model?: Model;
        sessionId?: string;
        turnId: string;
        attempt: number;
        transport: "stream" | "websocket";
      };
    },
  ):
    | {
        headers?: Record<string, string>;
        metadata?: Record<string, string>;
        websocket?: {
          headers?: Record<string, string>;
          degradeCooldownMs?: number;
        };
      }
    | undefined;
  wrapSimpleCompletionStream(
    this: void,
    params: {
      provider: string;
      config?: unknown;
      context: AiProviderStreamHookContext & { streamFn: StreamFn };
    },
  ): StreamFn | undefined;
  createAnthropicVertexStream(
    this: void,
    model: Pick<Model, "baseUrl">,
    env?: NodeJS.ProcessEnv,
  ): StreamFn;
}

/** Host-owned transcript normalization contract used immediately before provider projection. */
export type AiTransformTransportMessages = (
  messages: Context["messages"],
  model: Model,
  normalizeToolCallId?: (
    id: string,
    targetModel: Model,
    source: { provider: string; api: Api; model: string },
  ) => string,
  options?: {
    normalizeSameModelToolCallIds?: boolean;
    preserveCrossModelToolCallThoughtSignature?: boolean;
    preserveUnframedToolResults?: boolean;
  },
) => Context["messages"];

/** Strict-tool policy inputs for OpenAI-compatible routes. */
export interface OpenAIStrictToolSettingOptions {
  transport?: "stream" | "websocket";
  supportsStrictMode?: boolean;
}

export type AiInlineTextBlock = { type: "text"; text: string };
export type AiInlineImageBlock = { type: "image"; data: string; mimeType: string };
export type AiInlineContentBlock = AiInlineTextBlock | AiInlineImageBlock;
type AnthropicInlineContentNormalizer = (
  content: readonly AiInlineContentBlock[],
) => Promise<AiInlineContentBlock[]>;

/** Narrow host ports consumed by the built-in provider adapters. */
export interface AiTransportHost {
  /** Creates background resources outside the embedding application's request contexts. */
  runInDetachedAsyncContext<T>(run: () => T): T;
  /** Retains accepted lifecycle work after its caller observes cancellation. */
  observePendingProviderWork?: (pending: Promise<unknown>) => void;
  /**
   * Builds a policy-guarded fetch for one model request.
   * Returning undefined keeps the provider SDK's default fetch.
   */
  buildModelFetch(
    model: Model,
    timeoutMs?: number,
    options?: { sanitizeSse?: boolean; onSseComment?: () => void },
  ): typeof fetch | undefined;
  /** Resolves host-owned process-local secret sentinel substrings immediately before egress. */
  resolveSecretSentinel(value: string): string;
  /** Resolves visible headers and host-private request overrides before plugin handoff. */
  unwrapModelTransportSentinels?<T extends Model>(model: T, boundary: string): T;
  /** Redacts transport diagnostic text before logging. */
  redactToolPayloadText(text: string): string;
  /** Normalizes Anthropic inline image blocks before provider payload construction. */
  normalizeAnthropicInlineContentBlocks?: AnthropicInlineContentNormalizer;
  /**
   * Resolves the host strict-tool default for OpenAI-compatible routes.
   * undefined lets the request omit the strict flag entirely.
   */
  resolveOpenAIStrictToolSetting(
    model: Pick<Model, "provider" | "api" | "baseUrl" | "id"> & { compat?: unknown },
    options?: OpenAIStrictToolSettingOptions,
  ): boolean | undefined;
  /** Provider-plugin operations required by the generic package transports. */
  plugin: AiTransportPluginHost;
  /** Builds provider-owned Copilot compatibility headers for one message turn. */
  buildCopilotDynamicHeaders(messages: Context["messages"]): Record<string, string>;
  /** Resolves provider capability flags used by payload compatibility policy. */
  resolveProviderRequestCapabilities(
    input: AiProviderRequestPolicyInput,
  ): AiProviderRequestCapabilities;
  /** Merges host-owned provider request headers and attribution policy. */
  resolveProviderRequestHeaders(input: {
    provider?: string;
    api?: string;
    baseUrl?: string;
    providerHeaders?: ModelRequestHeaders;
    callerHeaders?: ModelRequestHeaders;
    precedence?: "caller-wins" | "defaults-win";
    model?: object;
  }): ModelRequestHeaders | undefined;
  /** Returns the host-configured request timeout attached to a model. */
  resolveModelRequestTimeoutMs(model: Model): number | undefined;
  /** With scope "fetch", requires guarded fetch dispatch; native WebSockets must also exclude it. */
  requiresManagedTransport(model: Model, scope?: "fetch"): boolean;
  /** Copies host-owned managed-transport state onto a projected model. */
  inheritManagedTransport(source: Model, target: Model): Model;
  /** Host-owned deep-immutability proof; absent hosts simply convert each request. */
  immutableData?: {
    isPlainData?(this: void, value: unknown): boolean;
    isDeeplyFrozenPlainData(value: unknown): boolean;
    freezeJsonSnapshot<T>(value: T): T;
  };
  /** Applies host-owned transcript replay and pairing rules. */
  transformTransportMessages: AiTransformTransportMessages;
  /** Registers a custom transport API with the host's stream error bridge. */
  registerCustomApi(registry: ApiRegistry, api: Api, streamFn: StreamFn): boolean;
  /** Optional for existing embedding hosts; omitted means the host decides at emission. */
  isLogEnabled?(subsystem: string, level: "debug" | "info" | "warn"): boolean;
  /**
   * Emits one transport diagnostic; build runs only when the host logs it and
   * may return null to suppress the entry (e.g. de-duplication).
   */
  logDebug(
    subsystem: string,
    build: () => { message: string; data?: Record<string, unknown> } | null,
  ): void;
  /** Emits an informational transport diagnostic through the host logger. */
  logInfo(subsystem: string, message: string, data?: Record<string, unknown>): void;
  /** Emits a warning through the host logger. */
  logWarn(subsystem: string, message: string, data?: Record<string, unknown>): void;
}

const MAX_PENDING_CUSTOM_API_REGISTRATIONS = 32;

const pendingCustomApiRegistrations: Array<{
  registry: ApiRegistry;
  api: Api;
  streamFn: StreamFn;
}> = [];

function queueCustomApiRegistration(registry: ApiRegistry, api: Api, streamFn: StreamFn): boolean {
  const existing = pendingCustomApiRegistrations.find(
    (registration) => registration.registry === registry && registration.api === api,
  );
  if (existing) {
    existing.streamFn = streamFn;
    return false;
  }
  if (pendingCustomApiRegistrations.length >= MAX_PENDING_CUSTOM_API_REGISTRATIONS) {
    throw new Error("Too many custom transport APIs were registered before host configuration");
  }
  pendingCustomApiRegistrations.push({ registry, api, streamFn });
  return false;
}

type ActiveAiTransportHost = Omit<AiTransportHost, "normalizeAnthropicInlineContentBlocks"> & {
  normalizeAnthropicInlineContentBlocks: AnthropicInlineContentNormalizer;
};

const inertAiTransportHost: ActiveAiTransportHost = {
  runInDetachedAsyncContext: (run) => run(),
  buildModelFetch: () => undefined,
  resolveSecretSentinel: (value) => value,
  redactToolPayloadText: (text) => text,
  normalizeAnthropicInlineContentBlocks: async (content) => [...content],
  resolveOpenAIStrictToolSetting: (_model, options) =>
    options?.supportsStrictMode ? false : undefined,
  plugin: {
    resolveProviderStream: () => undefined,
    resolveTransportTurnState: () => undefined,
    wrapSimpleCompletionStream: () => undefined,
    createAnthropicVertexStream: () => {
      throw new Error("Anthropic Vertex transport is not configured by the embedding host");
    },
  },
  buildCopilotDynamicHeaders: () => ({}),
  resolveProviderRequestCapabilities: () => ({
    endpointClass: "default",
    knownProviderFamily: "",
    supportsNativeStreamingUsageCompat: false,
    supportsOpenAICompletionsStreamingUsageCompat: false,
    usesExplicitProxyLikeEndpoint: false,
    allowsAnthropicServiceTier: false,
  }),
  resolveProviderRequestHeaders: ({ providerHeaders, callerHeaders, precedence }) => ({
    ...(precedence === "caller-wins" ? providerHeaders : callerHeaders),
    ...(precedence === "caller-wins" ? callerHeaders : providerHeaders),
  }),
  resolveModelRequestTimeoutMs: () => undefined,
  requiresManagedTransport: () => false,
  inheritManagedTransport: (_source, target) => target,
  transformTransportMessages: (messages, model, normalizeToolCallId) =>
    transformMessages(messages, model, normalizeToolCallId),
  registerCustomApi: queueCustomApiRegistration,
  isLogEnabled: () => true,
  logDebug: () => {},
  logInfo: () => {},
  logWarn: () => {},
};

let activeAiTransportHost: ActiveAiTransportHost = inertAiTransportHost;
type ProcessWithAsyncHooksBuiltin = NodeJS.Process & {
  getBuiltinModule?: (id: "node:async_hooks") => {
    AsyncLocalStorage: new <T>() => {
      getStore(): T | undefined;
      run<R>(store: T, callback: () => R): R;
    };
  };
};

function createAiTransportHostScope() {
  if (typeof process === "undefined") {
    return undefined;
  }
  // SAFETY: Node's Process type can lag the process.getBuiltinModule runtime API.
  const asyncHooks = (process as ProcessWithAsyncHooksBuiltin).getBuiltinModule?.(
    "node:async_hooks",
  );
  return asyncHooks ? new asyncHooks.AsyncLocalStorage<ActiveAiTransportHost>() : undefined;
}

// Avoid a static node:async_hooks import: provider modules also load in browser/Vite builds.
const scopedAiTransportHost = createAiTransportHostScope();
let pendingUnscopedHost: ActiveAiTransportHost | undefined;
let pendingUnscopedOperations = 0;

function isPromiseLike(value: unknown): value is PromiseLike<unknown> {
  return (
    value !== null &&
    (typeof value === "object" || typeof value === "function") &&
    typeof Reflect.get(value, "then") === "function"
  );
}

function trackUnscopedOperation(host: ActiveAiTransportHost, result: unknown): void {
  if (!isPromiseLike(result)) {
    return;
  }
  pendingUnscopedHost = host;
  pendingUnscopedOperations += 1;
  const release = () => {
    pendingUnscopedOperations -= 1;
    if (pendingUnscopedOperations === 0) {
      pendingUnscopedHost = undefined;
    }
  };
  void Promise.resolve(result).then(release, release);
}

/** Reports whether distinct host policy can survive asynchronous work. */
export function supportsScopedAiTransportHosts(): boolean {
  return scopedAiTransportHost !== undefined;
}

/** Resolves an explicit embedding policy without replacing the process default. */
export function createAiTransportHost(host: Partial<AiTransportHost> = {}): ActiveAiTransportHost {
  return {
    ...inertAiTransportHost,
    ...host,
    normalizeAnthropicInlineContentBlocks:
      host.normalizeAnthropicInlineContentBlocks ??
      inertAiTransportHost.normalizeAnthropicInlineContentBlocks,
    plugin: { ...inertAiTransportHost.plugin, ...host.plugin },
  };
}

/** Provider operations retain their policy across lazy loads and asynchronous I/O. */
export function runWithAiTransportHost<T>(host: ActiveAiTransportHost, run: () => T): T {
  if (!scopedAiTransportHost) {
    if (host !== activeAiTransportHost) {
      throw new Error("Scoped AI transport hosts require Node.js async context support");
    }
    if (pendingUnscopedHost && pendingUnscopedHost !== host) {
      throw new Error("AI transport host changed while browser provider work was still pending");
    }
    const result = run();
    trackUnscopedOperation(host, result);
    return result;
  }
  return scopedAiTransportHost.run(host, run);
}

/** Installers must read the process default, never an unrelated operation's scoped policy. */
export function getDefaultAiTransportHost(): ActiveAiTransportHost {
  return activeAiTransportHost;
}

/** Installs host implementations for the transport policy ports. */
export function configureAiTransportHost(host: Partial<AiTransportHost>): void {
  if (!scopedAiTransportHost && pendingUnscopedOperations > 0) {
    throw new Error("Cannot replace the AI transport host while browser provider work is pending");
  }
  activeAiTransportHost = createAiTransportHost(host);
  const transportHost = activeAiTransportHost;
  if (
    transportHost.registerCustomApi === inertAiTransportHost.registerCustomApi ||
    pendingCustomApiRegistrations.length === 0
  ) {
    return;
  }

  // Transport modules may register before host wiring. Drain once after a concrete
  // registrar installs so module caching cannot permanently lose those registrations.
  const pending = pendingCustomApiRegistrations.splice(0);
  for (const registration of pending) {
    transportHost.registerCustomApi(registration.registry, registration.api, registration.streamFn);
  }
}

/** Returns the active transport host (inert defaults unless configured). */
export function getAiTransportHost(): ActiveAiTransportHost {
  return scopedAiTransportHost?.getStore() ?? activeAiTransportHost;
}

/** Resolves sentinel substrings in custom headers at a no-fetch adapter boundary. */
export function resolveAiTransportHeaderSentinels(
  headers: ModelRequestHeaders | undefined,
): ModelRequestHeaders | undefined {
  if (!headers) {
    return undefined;
  }
  const host = getAiTransportHost();
  let resolvedHeaders: ModelRequestHeaders | undefined;
  for (const [name, value] of Object.entries(headers)) {
    if (value === null) {
      // Keep SDK deletion sentinels opaque to credential resolution.
      continue;
    }
    const resolved = host.resolveSecretSentinel(value);
    if (resolved !== value) {
      resolvedHeaders ??= { ...headers };
      resolvedHeaders[name] = resolved;
    }
  }
  return resolvedHeaders ?? headers;
}
