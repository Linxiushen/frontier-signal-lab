"""Unmodified-base HTTP collision reproduction, no native/model execution."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time,urllib.request,urllib.error
R=Path.cwd();D=Path(__file__).resolve().parent/'h2-namespace'/'base-reproduction';D.mkdir(parents=True,exist_ok=False)
records=[];started=datetime.now(timezone.utc).isoformat()
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True).stdout.decode().strip()
assert head=='2a7eed62ac6676a1cf81beb6b04c696c93593f6f'
assert not subprocess.run(['git','status','--porcelain'],capture_output=True,check=True).stdout
stdout=(D/'server.stdout').open('wb');stderr=(D/'server.stderr').open('wb')
p=subprocess.Popen([sys.executable,'-X','utf8','-B','-S','experiments/pi_effect_http_server.py','--output',str(D),'--stage','0'],stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
base=None;failure=None
def request(method,path,value=None):
 raw=None if value is None else json.dumps(value).encode()
 req=urllib.request.Request(base+path,raw,{'x-frontier-fixture':'local-fixture-v1','Content-Type':'application/json'},method=method)
 try:
  with urllib.request.urlopen(req,timeout=2) as response:status,body=response.status,json.load(response)
 except urllib.error.HTTPError as error:status,body=error.code,json.load(error)
 records.append({'method':method,'path':path,'request':value,'status':status,'body':body})
 return status,body
try:
 deadline=time.monotonic()+5
 while not (D/'effect-server0-ready.json').exists():
  assert p.poll() is None and time.monotonic()<deadline,'server startup failed'
  time.sleep(.01)
 base=json.loads((D/'effect-server0-ready.json').read_bytes())['base']
 payload='same-content';key='1:same-request'
 value={'key':key,'payload':payload,'version':1,'conversation':1,'fingerprint':hashlib.sha256(payload.encode()).hexdigest()}
 for scope in ('service0','service1'):assert request('POST','authority',{'scope':scope,'conversation':1,'version':1,'allowed':True})[0]==200
 assert request('POST','effects/'+key,{**value,'scope':'service0'})[0]==201
 first_lookup=request('GET','effects/'+key)
 second=request('POST','effects/'+key,{**value,'scope':'service1'})
 assert second[0]==201, f'Independent service1 same native/request key should create its own effect; actual HTTP{second[0]} {second[1]}'
except BaseException as error:
 failure={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 if base:
  try:request('POST','stop',{})
  except Exception:pass
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 stdout.close();stderr.close()
 receipt={'started_at':started,'completed_at':datetime.now(timezone.utc).isoformat(),'unmodified_head':head,'failure':failure,'requests':records,'server_exit':p.returncode,'server_pid':p.pid,'real_native_sessions':0,'scientific_experiments':0,'model_loads':0,'scope':'Real loopback HTTP into original SQLite effect store; two trusted fixture service scopes with same canonical conversation/request key. Failure is cross-service collision/liveness, not unauthorized effect or production claim.'}
 (D/'reproduction.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
